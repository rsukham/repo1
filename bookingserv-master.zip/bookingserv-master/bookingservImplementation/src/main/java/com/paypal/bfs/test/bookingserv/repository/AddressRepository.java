package com.paypal.bfs.test.bookingserv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paypal.bfs.test.bookingserv.model.Address;

public interface AddressRepository extends JpaRepository<Address, Integer>{

}
