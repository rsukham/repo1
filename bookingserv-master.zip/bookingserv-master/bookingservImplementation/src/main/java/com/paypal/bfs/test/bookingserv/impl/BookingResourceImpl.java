package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.exception.InvalidInputException;
import com.paypal.bfs.test.bookingserv.repository.AddressRepository;
import com.paypal.bfs.test.bookingserv.repository.BookingRepository;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class BookingResourceImpl implements BookingResource {

	private ModelMapper mapper = new ModelMapper();
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	

	@Override
	public ResponseEntity<Booking> create(Booking booking) {

		validateInput(booking);
		com.paypal.bfs.test.bookingserv.model.Booking bookingObject = mapper.map(booking, com.paypal.bfs.test.bookingserv.model.Booking.class);
		
		com.paypal.bfs.test.bookingserv.model.Booking bookingDBObject = bookingRepository.findByFirstNameAndLastName(bookingObject.getFirstName(), bookingObject.getLastName());
		if(bookingDBObject != null) {
			bookingObject.setId(bookingDBObject.getId());
			bookingObject.getAddress().setId(bookingDBObject.getAddress().getId());
		}
		
		addressRepository.save(bookingObject.getAddress());
		bookingObject = bookingRepository.saveAndFlush(bookingObject);
		booking = mapper.map(bookingObject, Booking.class);
		ResponseEntity<Booking> entity = new ResponseEntity<Booking>(booking, HttpStatus.CREATED);
		return entity;
	}



	@Override
	public ResponseEntity<List<Booking>> getBookings() {
		List<Booking> results = new ArrayList<>();
		List<com.paypal.bfs.test.bookingserv.model.Booking> bookings = bookingRepository.findAll();
		for (com.paypal.bfs.test.bookingserv.model.Booking booking : bookings) {
			results.add(mapper.map(booking, Booking.class));
		}
		
		ResponseEntity<List<Booking>> entity = new ResponseEntity<List<Booking>>(results, HttpStatus.OK);
		return entity;
	}
	
	private void validateInput(Booking booking) {
		
		if(StringUtils.isEmpty(booking.getFirstName()) || StringUtils.isEmpty(booking.getLastName()) ) {
			throw new InvalidInputException("Bad Input!!");
		}
		
	}

	
}
